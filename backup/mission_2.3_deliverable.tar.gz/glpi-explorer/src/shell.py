from rich.table import Table
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from src.api_client import ApiClient
from src.config_manager import ConfigManager

class GLPIExplorerShell:
    def __init__(self):
        self.console = Console()
        self.api_client = None
        self.TYPE_ALIASES = {
            'computer': 'Computer', 'pc': 'Computer',
            'switch': 'NetworkEquipment', 'sw': 'NetworkEquipment',
            'patchpanel': 'PassiveDevice', 'patch': 'PassiveDevice', 'pp': 'PassiveDevice',
            'walloutlet': 'PassiveDevice', 'wo': 'PassiveDevice',
            'hub': 'NetworkEquipment', 'hb': 'NetworkEquipment',
            'cable': 'Cable', 'cb': 'Cable',
        }

    def _is_config_valid(self, config):
        if not isinstance(config, dict):
            return False
        required_keys = ["url", "app_token", "user_token"]
        for key in required_keys:
            if key not in config or not config[key]:
                return False
        return True

    def run(self):
        config_manager = ConfigManager()
        config = config_manager.load_config()

        if not self._is_config_valid(config):
            self.console.print(Panel("[bold blue]Bienvenue... ou la configuration est invalide.[/bold blue]\n[yellow]Il semble que ce soit votre première utilisation ou que la configuration précédente soit manquante ou corrompue.\nNous allons vous guider à travers le processus de configuration.[/yellow]", expand=False))
            while True:
                config = config_manager.run_setup_interactive()
                api_client_test = ApiClient(config)
                with self.console.status("[bold green]Test de la connexion API...[/bold green]"):
                    is_connected = api_client_test.connect()

                if not is_connected:
                    self.console.print(Panel(f"[bold red]Échec de la connexion :[/bold red] Veuillez réessayer avec des informations valides.", title="[red]Erreur de Connexion[/red]"))
                else:
                    api_client_test.close_session() # Ferme la session de test immédiatement
                    config_manager.save_config(config)
                    self.console.print(Panel("[bold green]Configuration sauvegardée avec succès ![/bold green]", title="[green]Succès[/green]"))
                    break

        # Logique de connexion principale
        self.api_client = ApiClient(config)
        with self.console.status("[bold green]Connexion à l'API GLPI...[/bold green]"):
            is_connected = self.api_client.connect()

        if not is_connected:
            self.console.print(Panel(f"[bold red]Échec de la connexion principale :[/bold red] Veuillez vérifier votre configuration ou relancer l'application pour reconfigurer.", title="[red]Erreur[/red]"))
            return

        self.console.print(Panel("Bienvenue dans GLPI Explorer", title="[bold cyan]GLPI Explorer[/]", subtitle="[green]v0.1[/]"))

        while True:
            try:
                full_command = self.console.input("[bold cyan](glpi-explorer)> [/]").strip()
                if not full_command:
                    continue
                parts = full_command.split(maxsplit=1)
                command = parts[0].lower()
                args = parts[1] if len(parts) > 1 else ""

                if command in ("exit", "quit"):
                    if self.api_client:
                        self.api_client.close_session()
                elif command == "get":
                    if not args:
                        self.console.print(Panel("[bold red]Erreur:[/bold red] La commande 'get' nécessite deux arguments.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
                        continue
                    
                    # Tenter de séparer le type du nom. Le nom est tout ce qui suit le type.
                    try:
                        user_type_alias, item_name = args.split(maxsplit=1)
                    except ValueError:
                        # Cette erreur se produit si 'args' ne contient qu'un seul mot.
                        self.console.print(Panel("[bold red]Erreur:[/bold red] Syntaxe incorrecte. Il manque soit le type, soit le nom de l'objet.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
                        continue

                    glpi_itemtype = self.TYPE_ALIASES.get(user_type_alias.lower())
                    
                    if not glpi_itemtype:
                        self.console.print(Panel(f"[bold red]Erreur:[/bold red] Le type '{user_type_alias}' est inconnu.", title="[red]Type Inconnu[/red]"))
                        continue
                    
                    # Le reste de la logique (status, appel api, affichage) qui suit est probablement déjà correct,
                    # mais il dépendait de la bonne définition des variables glpi_itemtype et item_name.
                    # Assurez-vous qu'il utilise bien ces variables.
                    with self.console.status(f"Recherche de '{item_name}' ({glpi_itemtype})..."):
                        # La méthode dans api_client.py a été renommée en search_item, assurons-nous d'utiliser le bon nom.
                        item_id = self.api_client.search_item(glpi_itemtype, item_name)

                    if item_id is None:
                        self.console.print(Panel(f"[bold red]Erreur:[/bold red] Aucun élément de type '{user_type_alias}' nommé '{item_name}' trouvé.", title="[red]Non trouvé[/red]"))
                    else:
                        with self.console.status(f"[bold green]Récupération des détails de {item_name}...[/bold green]"):
                            details = self.api_client.get_item_details(glpi_itemtype, item_id)
                        
                        # Le reste du code d'affichage de la table est bon.
                        if details:
                            table = Table(show_header=False, show_edge=False, box=None, padding=0)
                            table.add_column("Key", style="bold cyan")
                            table.add_column("Value", style="green")

                            table.add_row("ID", str(details.get("id")))
                            table.add_row("Nom", details.get("name"))
                            table.add_row("Type GLPI", glpi_itemtype)
                            status = details.get("states_id", "N/A")
                            location = details.get("locations_id", "N/A")

                            table.add_row("Statut", status if isinstance(status, str) else "N/A")
                            table.add_row("Localisation", location if isinstance(location, str) else "N/A")

                            self.console.print(Panel(table, title=f"[bold blue]Détails de {item_name}[/bold blue]", expand=False))
                        else:
                            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Impossible de récupérer les détails pour '{item_name}'.", title="[red]Erreur[/red]"))
                elif command == "list":
                    if not args:
                        self.console.print(Panel("[bold red]Erreur:[/bold red] Usage: list <type>", title="[red]Utilisation[/red]"))
                        continue
                    
                    user_type_alias = args.lower()
                    glpi_itemtype = self.TYPE_ALIASES.get(user_type_alias)
                    if not glpi_itemtype:
                        self.console.print(Panel(f"[bold red]Erreur:[/bold red] Type inconnu: \'{user_type_alias}\'.", title="[red]Erreur[/red]"))
                        continue
                        
                    with self.console.status(f"Liste des objets de type {glpi_itemtype}..."):
                        items = self.api_client.list_items(glpi_itemtype)
                    
                    if not items:
                        self.console.print(Panel(f"Aucun objet de type \'{user_type_alias}\' trouvé.", title="[yellow]Résultat[/yellow]"))
                        continue
                    
                    table = Table(title=f"[bold blue]Liste des {glpi_itemtype}[/bold blue]")
                    table.add_column("ID", style="cyan", no_wrap=True)
                    table.add_column("Nom", style="magenta")
                    table.add_column("Statut", style="green")

                    for item in items:
                        table.add_row(
                            str(item.get("id", "N/A")),
                            item.get("name", "N/A"),
                            str(item.get("states_id", "N/A"))
                        )
                    self.console.print(Panel(table, expand=False))
                else:
                    self.console.print(Panel(f"[bold red]Commande inconnue:[/bold red] \'{command}\'. Commandes supportées: get, list, exit, quit", title="[red]Erreur[/red]"))

            except EOFError:
                # Ce bloc doit être au même niveau d'indentation que le "try"
                if self.api_client:
                    self.api_client.close_session()
                break
        



