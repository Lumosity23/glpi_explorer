
import requests
import json

class ApiClient:
    def __init__(self, config):
        self.config = config
        self.base_url = config.get("url")
        self.app_token = config.get("app_token")
        self.user_token = config.get("user_token")
        self.session_token = None

    def connect(self):
        headers = {
            "Authorization": f"user_token {self.user_token}",
            "App-Token": self.app_token,
            "Content-Type": "application/json"
        }
        try:
            response = requests.get(f"{self.base_url}/initSession", headers=headers)
            response.raise_for_status()
            session_token = response.json().get("session_token")
            if session_token:
                self.session_token = session_token
                return True
            return False
        except requests.exceptions.RequestException as e:
            print(f"Erreur de connexion: {e}")
            return False

    def close_session(self):
        if not self.session_token:
            return
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
        }
        try:
            requests.get(f"{self.base_url}/killSession", headers=headers)
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la fermeture de session: {e}")


    def search_item_by_name(self, item_name):
        if not self.session_token:
            return None, None
            
        item_types_to_search = ["Computer", "NetworkEquipment", "PassiveDevice"]
        
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
        }

        for itemtype in item_types_to_search:
            params = {
                "criteria[0][field]": "name",  # Utiliser le nom du champ, pas son ID
                "criteria[0][searchtype]": "contains",
                "criteria[0][value]": item_name
            }
            try:
                response = requests.get(f"{self.base_url}/search/{itemtype}", headers=headers, params=params)
                response.raise_for_status()
                data = response.json()
                
                # L'ancien projet s'attend à une clé "data" contenant une liste
                if isinstance(data, dict) and "data" in data and data["data"]:
                    first_item = data["data"][0]
                    item_id = first_item.get("id")
                    if item_id:
                        return itemtype, item_id
                # Gérer le cas où la réponse est directement une liste (certaines versions de l'API)
                elif isinstance(data, list) and data:
                    first_item = data[0]
                    item_id = first_item.get("id")
                    if item_id:
                        return itemtype, item_id
            except requests.exceptions.RequestException:
                # Si une recherche échoue pour un type, on continue avec le suivant
                continue
        
        return None, None

    def get_item_details(self, itemtype, item_id):
        if not self.session_token:
            return None
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
            "Content-Type": "application/json"
        }
        try:
            response = requests.get(f"{self.base_url}/{itemtype}/{item_id}", headers=headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la récupération des détails: {e}")
            return None




