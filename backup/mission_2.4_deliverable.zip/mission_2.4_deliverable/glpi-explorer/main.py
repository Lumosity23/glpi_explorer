from src.shell import GLPIExplorerShell

if __name__ == "__main__":
    shell = GLPIExplorerShell()
    shell.run()

