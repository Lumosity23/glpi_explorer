
from rich.console import Console
from rich.panel import Panel

class GLPIExplorerShell:
    def __init__(self):
        self.console = Console()

    def run(self):
        self.console.print(Panel("Bienvenue dans GLPI Explorer", title="[bold cyan]GLPI Explorer[/]", subtitle="[green]v0.1[/]"))

        while True:
            try:
                command = self.console.input("[bold cyan](glpi-explorer)> [/]").strip().lower()
                if command in ("exit", "quit"):
                    break
            except EOFError:
                break

        self.console.print("[yellow]Au revoir ![/yellow]")

