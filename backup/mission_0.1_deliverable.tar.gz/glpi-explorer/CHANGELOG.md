## [MISSION 0.1] - 2024-05-24 - par Manus

### Objectif de la Phase
Mise en place du socle de l'application CLI interactive, de sa structure de fichiers et de sa boucle de commande principale.

### Modifications Apportées
- **`glpi-explorer/`**: Création de l'arborescence initiale du projet.
- **`requirements.txt`**: Ajout des dépendances `rich` et `python-dotenv`.
- **`.gitignore`**: Configuration initiale pour les projets Python.
- **`main.py`**: Création du point d'entrée qui lance le shell interactif.
- **`src/shell.py`**: Implémentation de la classe `GLPIExplorerShell` avec une boucle de commande, un message de bienvenue, un prompt stylisé et la logique pour quitter (`exit`/`quit`).

