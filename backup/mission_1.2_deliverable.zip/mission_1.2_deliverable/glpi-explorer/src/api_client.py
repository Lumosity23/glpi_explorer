import requests

class ApiClient:
    def __init__(self, config):
        self.config = config
        self.base_url = self.config["url"]
        self.app_token = self.config["app_token"]
        self.user_token = self.config["user_token"]

    def connect(self):
        headers = {
            "App-Token": self.app_token,
            "Authorization": f"user_token {self.user_token}"
        }
        try:
            response = requests.get(f"{self.base_url}/initSession", headers=headers)
            response.raise_for_status()  # Lève une exception pour les codes d'état HTTP d'erreur
            session_token = response.json().get("session_token")
            if session_token:
                return True, session_token
            else:
                return False, "Session token non reçu."
        except requests.exceptions.HTTPError as e:
            return False, f"Erreur HTTP : {e.response.status_code} - {e.response.reason}"
        except requests.exceptions.ConnectionError:
            return False, f"Erreur de connexion. Impossible de joindre l\"URL : {self.base_url}"
        except requests.exceptions.RequestException as e:
            return False, f"Erreur de requête non spécifiée : {e}"

    def close_session(self, session_token):
        headers = {
            "App-Token": self.app_token,
            "Session-Token": session_token
        }
        try:
            requests.get(f"{self.base_url}/killSession", headers=headers)
        except requests.exceptions.RequestException:
            pass




    def search_item_by_name(self, item_name, session_token):
        item_types = ['Computer', 'NetworkEquipment', 'PassiveDevice']
        headers = {
            "App-Token": self.app_token,
            "Session-Token": session_token
        }

        for itemtype in item_types:
            params = {
                'criteria[0][field]': 2,
                'criteria[0][searchtype]': 'contains',
                'criteria[0][value]': item_name
            }
            try:
                response = requests.get(f"{self.base_url}/search/{itemtype}", headers=headers, params=params)
                response.raise_for_status()
                data = response.json().get('data')
                if data and len(data) > 0:
                    return itemtype, data[0].get('id')
            except requests.exceptions.RequestException:
                continue
        return None, None




    def get_item_details(self, itemtype, item_id, session_token):
        headers = {
            "App-Token": self.app_token,
            "Session-Token": session_token
        }
        params = {
            "expand_dropdowns": "true",
            "with_networkports": "true"
        }
        try:
            response = requests.get(f"{self.base_url}/{itemtype}/{item_id}", headers=headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException:
            return None


