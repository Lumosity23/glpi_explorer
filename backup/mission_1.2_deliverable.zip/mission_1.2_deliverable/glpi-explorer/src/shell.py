from rich.table import Table
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from src.api_client import ApiClient
from src.config_manager import ConfigManager

class GLPIExplorerShell:
    def __init__(self):
        self.console = Console()
        self.api_client = None
        self.session_token = None

    def run(self):
        config_manager = ConfigManager()
        config = config_manager.load_config()

        if config is None:
            self.console.print(Panel("[bold blue]Bienvenue dans GLPI Explorer ![/bold blue]\n\n[yellow]Il semble que ce soit votre première utilisation ou que la configuration précédente soit manquante.\nNous allons vous guider à travers le processus de configuration.[/yellow]", expand=False))
            while True:
                config = config_manager.run_setup_interactive()
                api_client_test = ApiClient(config)
                with self.console.status("[bold green]Test de la connexion API...[/bold green]"):
                    is_connected, message = api_client_test.connect()

                if not is_connected:
                    self.console.print(Panel(f"[bold red]Échec de la connexion :[/bold red] {message}\n[yellow]Veuillez réessayer avec des informations valides.[/yellow]", title="[red]Erreur de Connexion[/red]"))
                else:
                    test_session_token = message # message contient le token ici
                    # Fermer la session de test immédiatement pour ne pas laisser de token orphelin
                    api_client_test.close_session(test_session_token)
                    
                    config_manager.save_config(config)
                    self.console.print(Panel("[bold green]Configuration sauvegardée avec succès ![/bold green]", title="[green]Succès[/green]"))
                    break

        # Logique de connexion principale
        self.api_client = ApiClient(config)
        with self.console.status("[bold green]Connexion à l'API GLPI...[/bold green]"):
            is_connected, message = self.api_client.connect()

        if not is_connected:
            self.console.print(Panel(f"[bold red]Échec de la connexion principale :[/bold red] {message}\n[yellow]Veuillez vérifier votre configuration ou relancer l'application pour reconfigurer.[/yellow]", title="[red]Erreur[/red]"))
            return
        else:
            self.session_token = message # message is the session_token here

        self.console.print(Panel("Bienvenue dans GLPI Explorer", title="[bold cyan]GLPI Explorer[/]", subtitle="[green]v0.1[/]"))

        while True:
            try:
                full_command = self.console.input("[bold cyan](glpi-explorer)> [/]").strip()
                if not full_command:
                    continue
                parts = full_command.split(maxsplit=1)
                command = parts[0].lower()
                args = parts[1] if len(parts) > 1 else ""

                if command in ("exit", "quit"):
                    if self.api_client and self.session_token:
                        self.api_client.close_session(self.session_token)
                    break
                elif command == "get":
                    if not args:
                        self.console.print(Panel("[bold red]Erreur:[/bold red] La commande 'get' nécessite un argument (ex: get pc-01)", title="[red]Utilisation[/red]"))
                        continue
                    
                    item_name = args
                    with self.console.status(f"[bold green]Recherche de {item_name}...[/bold green]"):
                        itemtype, item_id = self.api_client.search_item_by_name(item_name, self.session_token)

                    if itemtype is None:
                        self.console.print(Panel(f"[bold red]Erreur:[/bold red] Aucun élément nommé '{item_name}' trouvé.", title="[red]Non trouvé[/red]"))
                    else:
                        with self.console.status(f"[bold green]Récupération des détails de {item_name}...[/bold green]"):
                            details = self.api_client.get_item_details(itemtype, item_id, self.session_token)
                        
                        if details:
                            table = Table(show_header=False, show_edge=False, box=None, padding=0)
                            table.add_column("Key", style="bold cyan")
                            table.add_column("Value", style="green")

                            table.add_row("ID", str(details.get("id")))
                            table.add_row("Nom", details.get("name"))
                            table.add_row("Type GLPI", itemtype)
                            status = details.get("states_id", "N/A")
                            location = details.get("locations_id", "N/A")

                            table.add_row("Statut", status if isinstance(status, str) else "N/A")
                            table.add_row("Localisation", location if isinstance(location, str) else "N/A")

                            self.console.print(Panel(table, title=f"[bold blue]Détails de {item_name}[/bold blue]", expand=False))
                        else:
                            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Impossible de récupérer les détails pour '{item_name}'.", title="[red]Erreur[/red]"))
                else:
                    self.console.print(Panel(f"[bold red]Commande inconnue:[/bold red] '{command}'. Commandes supportées: get, exit, quit", title="[red]Erreur[/red]"))

            except EOFError:
                if self.api_client and self.session_token:
                    self.api_client.close_session(self.session_token)
                break

        self.console.print("[yellow]Au revoir ![/yellow]")


