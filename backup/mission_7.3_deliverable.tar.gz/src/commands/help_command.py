from src.commands.base_command import BaseCommand
from rich.table import Table
from rich.panel import Panel

class HelpCommand(BaseCommand):
    def __init__(self, api_client, console, commands_map):
        super().__init__(api_client, console)
        self.commands_map = commands_map

    def execute(self, args):
        help_table = Table(title="Commandes Disponibles", show_header=True, header_style="bold magenta")
        help_table.add_column("Commande")
        help_table.add_column("Description")
        help_table.add_column("Usage")

        for cmd_name, cmd_instance in self.commands_map.items():
            try:
                help_message = cmd_instance.get_help_message()
                help_table.add_row(cmd_name, help_message["description"], help_message["usage"])
            except Exception as e:
                self.console.print(f"[bold red]Erreur lors de la récupération de l'aide pour {cmd_name}: {e}[/bold red]")
                help_table.add_row(cmd_name, "N/A", "N/A")

        # Add aliases manually as they are handled in shell.py, not as separate command classes
        help_table.add_row("ls", "Alias pour la commande 'list'", "ls <type>")
        help_table.add_row("q", "Alias pour la commande 'exit'", "q")

        self.console.print(Panel(help_table, title="[bold blue]Aide GLPI Explorer[/bold blue]"))

    def get_help_message(self):
        return {
            "description": "Affiche ce message d'aide.",
            "usage": "help"
        }

