from src.commands.base_command import BaseCommand
from rich.table import Table
from rich.panel import Panel
from rich.console import Group
from rich.text import Text
from rich import box
from src.api_client import ApiClient

class GetCommand(BaseCommand):
    def execute(self, args):
        if not args:
            self.console.print(Panel("[bold red]Erreur:[/bold red] La commande 'get' nécessite deux arguments.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
            return
        
        try:
            user_type_alias, item_name = args.split(maxsplit=1)
        except ValueError:
            self.console.print(Panel("[bold red]Erreur:[/bold red] Syntaxe incorrecte. Il manque soit le type, soit le nom de l'objet.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
            return

        glpi_itemtype = self.TYPE_ALIASES.get(user_type_alias.lower())
        
        if not glpi_itemtype:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Le type '{user_type_alias}' est inconnu.", title="[red]Type Inconnu[/red]"))
            return
        
        with self.console.status(f"Récupération de la liste des '{glpi_itemtype}'..."):
            # On demande tous les items du type donné
            all_items = self.api_client.list_items(glpi_itemtype, item_range="0-9999")

        if not all_items:
            self.console.print(Panel(f"Aucun objet de type '{user_type_alias}' trouvé dans GLPI.", title="[blue]Information[/blue]", border_style="blue"))
            return

        # Recherche de l'item par son nom dans la liste reçue
        found_item = None
        for item in all_items:
            # On peut rendre la comparaison insensible à la casse pour plus de flexibilité
            if item.get("name", "").lower() == item_name.lower():
                found_item = item
                break
        
        if found_item is None:
            self.console.print(Panel(f"Erreur: Aucun objet de type '{user_type_alias}' nommé '{item_name}' trouvé.", title="[red]Non trouvé[/red]"))
            return

        # On a trouvé l'item, on a son ID
        item_id = found_item.get("id")

        with self.console.status(f"Récupération des détails de {item_name}..."):
            details = self.api_client.get_item_details(glpi_itemtype, item_id)
        
        if details:
            info_table = Table(title="Informations Générales", show_header=True, box=box.ROUNDED, header_style="bold cyan")
            info_table.add_column("ID", style="cyan")
            info_table.add_column("Nom", style="magenta")
            info_table.add_column("Type", style="green")
            info_table.add_column("Statut", style="yellow")
            info_table.add_column("Localisation", style="blue")

            status = details.get("states_id", "N/A")
            location = details.get("locations_id", "N/A")

            info_table.add_row(
                str(details.get("id", "N/A")),
                details.get("name", "N/A"),
                glpi_itemtype,
                status if isinstance(status, str) else str(status),
                location if isinstance(location, str) else str(location)
            )

            ports_table = Table(title="Ports Réseau", expand=True)
            ports_table.add_column("Nom du Port", style="cyan")
            ports_table.add_column("Type", style="magenta")
            ports_table.add_column("Adresse MAC", style="yellow")
            ports_table.add_column("Vitesse (Mbps)", style="green", justify="right")

            has_ports = False
            # On récupère le dictionnaire de tous les ports
            network_ports_data = details.get("_networkports", {})
            
            if network_ports_data:
                # On parcourt chaque type de port (ex: 'NetworkPortEthernet', 'NetworkPortWifi')
                for port_type, port_list in network_ports_data.items():
                    if port_list: # S'il y a des ports de ce type
                        has_ports = True
                        # On parcourt chaque port dans la liste
                        for port in port_list:
                            ports_table.add_row(
                                port.get("name", "N/A"),
                                port_type, # Le type est la clé du dictionnaire
                                port.get("mac", "N/A"),
                                str(port.get("speed", "N/A"))
                            )

            # Affichage final dans le Panel
            renderables = [info_table]
            if has_ports:
                renderables.append(Text("")) # Ajoute un espace
                renderables.append(ports_table)
            
            render_group = Group(*renderables)
            
            self.console.print(Panel(render_group, title=f"[bold blue]Détails de {item_name}[/bold blue]", expand=False))
        else:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Impossible de récupérer les détails pour '{item_name}'.", title="[red]Erreur[/red]"))

