class BaseCommand:
    def __init__(self, api_client, console):
        self.api_client = api_client
        self.console = console
        self.TYPE_ALIASES = {
            'computer': 'Computer', 'pc': 'Computer',
            'monitor': 'Monitor', 'screen': 'Monitor',
            'networkequipment': 'NetworkEquipment', 'network': 'NetworkEquipment',
            'peripheral': 'Peripheral',
            'phone': 'Phone',
            'printer': 'Printer',
            'software': 'Software',
            'ticket': 'Ticket',
            'user': 'User'
        }

    def execute(self, args):
        # Cette méthode sera surchargée par chaque commande fille
        raise NotImplementedError


