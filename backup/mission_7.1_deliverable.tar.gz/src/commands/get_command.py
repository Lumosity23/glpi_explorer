from src.commands.base_command import BaseCommand
from rich.table import Table
from rich.panel import Panel
from rich.console import Group
from rich.text import Text
from rich import box
from src.api_client import ApiClient

class GetCommand(BaseCommand):
    def get_help_message(self):
        return {
            "description": "Récupère et affiche les détails d'un objet GLPI spécifique ou d'un port.",
            "usage": "get <type> <nom_objet> | get port <nom_port> on <nom_equipement>"
        }

    def execute(self, args):
        if not args:
            self.console.print(Panel("[bold red]Erreur:[/bold red] La commande 'get' nécessite des arguments.\nUsage: get <type> <nom_objet> | get port <nom_port> on <nom_equipement>", title="[red]Utilisation[/red]"))
            return

        parts = args.split(maxsplit=1)
        command_type = parts[0].lower()

        if command_type == "port":
            self._get_port_details(parts[1] if len(parts) > 1 else "")
        else:
            self._get_item_details(args)

    def _get_item_details(self, args):
        try:
            user_type_alias, item_name = args.split(maxsplit=1)
        except ValueError:
            self.console.print(Panel("[bold red]Erreur:[/bold red] Syntaxe incorrecte. Il manque soit le type, soit le nom de l'objet.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
            return

        glpi_itemtype = self.TYPE_ALIASES.get(user_type_alias.lower())
        
        if not glpi_itemtype:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Le type '{user_type_alias}' est inconnu.", title="[red]Type Inconnu[/red]"))
            return
        
        with self.console.status(f"Récupération de la liste des '{glpi_itemtype}'..."):
            all_items = self.api_client.list_items(glpi_itemtype, item_range="0-9999")

        if not all_items:
            self.console.print(Panel(f"Aucun objet de type '{user_type_alias}' trouvé dans GLPI.", title="[blue]Information[/blue]", border_style="blue"))
            return

        found_item = None
        for item in all_items:
            if item.get("name", "").lower() == item_name.lower():
                found_item = item
                break
        
        if found_item is None:
            self.console.print(Panel(f"Erreur: Aucun objet de type '{user_type_alias}' nommé '{item_name}' trouvé.", title="[red]Non trouvé[/red]"))
            return

        item_id = found_item.get("id")

        with self.console.status(f"Récupération des détails de {item_name}..."):
            details = self.api_client.get_item_details(glpi_itemtype, item_id)
        
        if details:
            if glpi_itemtype == "Cable":
                general_info_table = Table(title="Informations Générales du Câble", expand=True)
                general_info_table.add_column("ID")
                general_info_table.add_column("Nom")
                general_info_table.add_column("Type")
                general_info_table.add_column("Type Câble")

                general_info_table.add_row(
                    str(details.get("id")),
                    details.get("name"),
                    glpi_itemtype,
                    details.get("cabletypes_id", "N/A"),
                )

                endpoints_table = Table(title="Points de Connexion", expand=True)
                endpoints_table.add_column("Endpoint")
                endpoints_table.add_column("Type")
                endpoints_table.add_column("Socket")

                socket_a = details.get("sockets_id_endpoint_a", "N/A").replace("(&nbsp;)", "").strip()
                socket_b = details.get("sockets_id_endpoint_b", "N/A").replace("(&nbsp;)", "").strip()

                endpoints_table.add_row(
                    "A",
                    details.get("itemtype_endpoint_a", "N/A"),
                    socket_a,
                )
                endpoints_table.add_row(
                    "B",
                    details.get("itemtype_endpoint_b", "N/A"),
                    socket_b,
                )
                
                render_group = Group(general_info_table, Text(""), endpoints_table)
                self.console.print(Panel(render_group, title=f"[bold blue]Détails du Câble {item_name}[/bold blue]"))
            else:
                network_ports_data = details.get("_networkports", {})
                total_ports = 0
                if network_ports_data:
                    for port_list in network_ports_data.values():
                        total_ports += len(port_list)
                
                MAX_PORTS_FOR_SINGLE_TABLE = 5

                if total_ports <= MAX_PORTS_FOR_SINGLE_TABLE:
                    table = Table(title=f"Détails de {item_name}", expand=True)
                    
                    table.add_column("ID")
                    table.add_column("Nom")
                    table.add_column("Type")
                    table.add_column("Statut")
                    table.add_column("Localisation")
                    table.add_column("N. ports")

                    base_data = [
                        str(details.get("id")),
                        details.get("name"),
                        glpi_itemtype,
                        str(details.get("states_id", "N/A")),
                        str(details.get("locations_id", "N/A")),
                        str(total_ports),
                    ]

                    port_data = []
                    if network_ports_data:
                        for port_type, port_list in network_ports_data.items():
                            for port in port_list:
                                table.add_column(port.get("name", "Port sans nom"))
                                port_info = f"{port.get('speed', 'N/A')} Mbps"
                                port_data.append(port_info)

                    table.add_row(*(base_data + port_data))

                    self.console.print(Panel(table))
                else:
                    info_table = Table(title="Informations Générales", expand=True)
                    info_table.add_column("ID")
                    info_table.add_column("Nom")
                    info_table.add_column("Type")
                    info_table.add_column("Statut")
                    info_table.add_column("Localisation")
                    info_table.add_column("N. ports")
                    
                    info_table.add_row(
                        str(details.get("id")),
                        details.get("name"),
                        glpi_itemtype,
                        str(details.get("states_id", "N/A")),
                        str(details.get("locations_id", "N/A")),
                        str(total_ports),
                    )
                    
                    ports_table = Table(title="Ports Réseau", expand=True)
                    ports_table.add_column("Nom du Port")
                    ports_table.add_column("Type")
                    ports_table.add_column("MAC")
                    ports_table.add_column("Vitesse")
                    
                    for port_type, port_list in network_ports_data.items():
                        for port in port_list:
                            ports_table.add_row(
                                port.get("name", "N/A"),
                                str(port.get("networkporttypes_id", "N/A")),
                                port.get("mac", "N/A"),
                                f"{port.get('speed', 'N/A')} Mbps"
                            )
                    
                    render_group = Group(info_table, Text(""), ports_table)
                    self.console.print(Panel(render_group, title=f"[bold blue]Détails de {item_name}[/bold blue]"))
        else:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Impossible de récupérer les détails pour '{item_name}'.", title="[red]Erreur[/red]"))

    def _get_port_details(self, args):
        try:
            port_name, on_keyword, device_name = args.split(maxsplit=2)
            if on_keyword.lower() != "on":
                raise ValueError
        except ValueError:
            self.console.print(Panel("[bold red]Erreur:[/bold red] Syntaxe incorrecte pour 'get port'.\nUsage: get port <nom_port> on <nom_equipement>", title="[red]Utilisation[/red]"))
            return

        with self.console.status(f"Recherche de l'équipement '{device_name}'..."):
            possible_itemtypes = ["Computer", "NetworkEquipment", "Peripheral", "Monitor", "Phone", "Printer"] 
            found_device = None
            device_itemtype = None

            for itemtype_alias in possible_itemtypes:
                glpi_itemtype = self.TYPE_ALIASES.get(itemtype_alias.lower())
                if glpi_itemtype:
                    all_items = self.api_client.list_items(glpi_itemtype, item_range="0-9999")
                    for item in all_items:
                        if item.get("name", "").lower() == device_name.lower():
                            found_device = item
                            device_itemtype = glpi_itemtype
                            break
                if found_device:
                    break
            
            if found_device is None:
                self.console.print(Panel(f"[bold red]Erreur:[/bold red] Aucun équipement nommé '{device_name}' trouvé.", title="[red]Non trouvé[/red]"))
                return

        device_id = found_device.get("id")
        with self.console.status(f"Récupération des détails de l'équipement '{device_name}'..."):
            device_details = self.api_client.get_item_details(device_itemtype, device_id)

        if not device_details:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Impossible de récupérer les détails pour l'équipement '{device_name}'.", title="[red]Erreur[/red]"))
            return

        found_port = None
        network_ports_data = device_details.get("_networkports", {})
        for port_list in network_ports_data.values():
            for port in port_list:
                if port.get("name", "").lower() == port_name.lower():
                    found_port = port
                    break
            if found_port:
                break

        if found_port is None:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Aucun port nommé '{port_name}' trouvé sur l'équipement '{device_name}'.", title="[red]Non trouvé[/red]"))
            return

        port_table = Table(title=f"Détails du Port '{port_name}' sur '{device_name}'", expand=True)
        port_table.add_column("Propriété")
        port_table.add_column("Valeur")

        port_table.add_row("ID du Port", str(found_port.get("id", "N/A")))
        port_table.add_row("Nom du Port", found_port.get("name", "N/A"))
        port_table.add_row("Type de Port", str(found_port.get("networkporttypes_id", "N/A")))
        port_table.add_row("MAC", found_port.get("mac", "N/A"))
        port_table.add_row("Vitesse", f"{found_port.get('speed', 'N/A')} Mbps")
        port_table.add_row("Statut", str(found_port.get("states_id", "N/A")))
        port_table.add_row("Connecté à", found_port.get("connected", "Non connecté"))

        cable_info = None
        if found_port.get("id"):
            with self.console.status(f"Récupération des informations de câble pour le port '{port_name}'..."):
                cable_info = self.api_client.get_cable_on_port(found_port.get("id"))

        if cable_info:
            port_table.add_row("Câble Connecté", cable_info.get("name", "N/A"))
            other_end_id = None
            other_end_type = None
            if str(cable_info.get("item_a_id")) == str(found_port.get("id")) and cable_info.get("itemtype_a") == "NetworkPort":
                other_end_id = cable_info.get("item_b_id")
                other_end_type = cable_info.get("itemtype_b")
            elif str(cable_info.get("item_b_id")) == str(found_port.get("id")) and cable_info.get("itemtype_b") == "NetworkPort":
                other_end_id = cable_info.get("item_a_id")
                other_end_type = cable_info.get("itemtype_a")
            
            if other_end_id and other_end_type:
                with self.console.status(f"Récupération des détails de l'autre extrémité de la connexion (ID: {other_end_id}, Type: {other_end_type})..."):
                    connected_item_details = self.api_client.get_item_details(other_end_type, other_end_id)
                    if connected_item_details:
                        connected_name = connected_item_details.get("name", "Nom inconnu")
                        port_table.add_row("Connecté à (autre extrémité)", f"{connected_name} (ID: {other_end_id}, Type: {other_end_type})")
                    else:
                        port_table.add_row("Connecté à (autre extrémité)", f"ID: {other_end_id}, Type: {other_end_type} (Détails non récupérables)")
            else:
                port_table.add_row("Connecté à (autre extrémité)", "Non spécifié ou non-port")
        else:
            port_table.add_row("Câble Connecté", "Aucun")
            port_table.add_row("Connecté à (autre extrémité)", "N/A")

        self.console.print(Panel(port_table))

