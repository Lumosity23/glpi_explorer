class BaseCommand:
    def __init__(self, api_client, console):
        self.api_client = api_client
        self.console = console
        self.TYPE_ALIASES = {
            'computer': 'Computer', 'pc': 'Computer',
            'switch': 'NetworkEquipment', 'sw': 'NetworkEquipment',
            'hub': 'NetworkEquipment', 'hb': 'NetworkEquipment',
            'patchpanel': 'PassiveDevice', 'patch': 'PassiveDevice', 'pp': 'PassiveDevice',
            'walloutlet': 'PassiveDevice', 'wo': 'PassiveDevice',
            'cable': 'Cable', 'cb': 'Cable',
        }

    def execute(self, args):
        # Cette méthode sera surchargée par chaque commande fille
        raise NotImplementedError


