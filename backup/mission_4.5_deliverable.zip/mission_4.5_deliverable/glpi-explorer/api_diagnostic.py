import sys
import json
from rich.console import Console
from rich.panel import Panel
from rich import print_json

# Assurez-vous que le chemin vers src est dans sys.path
sys.path.insert(0, './src')

from src.api_client import ApiClient
from src.config_manager import ConfigManager

console = Console()

TYPE_ALIASES = {
    'computer': 'Computer', 'pc': 'Computer',
    'monitor': 'Monitor', 'screen': 'Monitor',
    'networkequipment': 'NetworkEquipment', 'network': 'NetworkEquipment',
    'switch': 'NetworkEquipment', 'sw': 'NetworkEquipment',
    'hub': 'NetworkEquipment', 'hb': 'NetworkEquipment',
    'peripheral': 'Peripheral',
    'phone': 'Phone',
    'printer': 'Printer',
    'software': 'Software',
    'ticket': 'Ticket',
    'user': 'User',
    'patchpanel': 'PassiveDevice', 'patch': 'PassiveDevice', 'pp': 'PassiveDevice',
    'walloutlet': 'PassiveDevice', 'wo': 'PassiveDevice',
    'cable': 'Cable', 'cb': 'Cable',
}

def _get_item_type(user_type_alias: str) -> str:
    return TYPE_ALIASES.get(user_type_alias.lower(), user_type_alias)

def main():
    if len(sys.argv) != 3:
        console.print(Panel(
            "[bold red]Erreur:[/bold red] Utilisation: python api_diagnostic.py <type> <nom_objet>",
            title="[red]Utilisation[/red]"
        ))
        sys.exit(1)

    user_type_alias = sys.argv[1]
    item_name = sys.argv[2]

    config_manager = ConfigManager()
    config = config_manager.load_config()

    if not config:
        console.print(Panel(
            "[bold red]Erreur:[/bold red] Configuration GLPI introuvable. Veuillez exécuter l'application principale pour la configurer.",
            title="[red]Erreur de Configuration[/red]"
        ))
        sys.exit(1)

    api_client = ApiClient(config)

    try:
        console.print("[bold blue]--- CONNEXION À L'API GLPI ---[/bold blue]")
        api_client.connect()
        console.print("[bold green]Connexion réussie.[/bold green]")

        glpi_itemtype = _get_item_type(user_type_alias)

        console.print("[bold blue]--- DÉBUT RECHERCHE ---[/bold blue]")
        # Répliquer la logique de search_item pour afficher les params
        search_params = [
            ('searchText', item_name),
            ('forcedisplay[0]', '2'), # ID
            ('forcedisplay[1]', '1'), # Name
            ('forcedisplay[2]', '80'), # Status
        ]
        search_url = f"{api_client.base_url}/{glpi_itemtype}"
        console.print(f"Requête de recherche URL: {search_url}")
        console.print(f"Requête de recherche Params: {search_params}")

        search_results = api_client.session.get(search_url, params=search_params)
        search_results.raise_for_status() # Lève une exception pour les codes d'état HTTP d'erreur
        search_data = search_results.json()
        console.print("[bold blue]Réponse de la recherche:[/bold blue]")
        print_json(data=search_data)

        item_id = None
        if 'data' in search_data and search_data['data']:
            # Chercher l'ID dans la liste des résultats
            for item in search_data['data']:
                if item.get('1') == item_name: # '1' est généralement le nom
                    item_id = item.get('2') # '2' est généralement l'ID
                    break
        
        if item_id:
            console.print(f"[bold green]ID trouvé:[/bold green] {item_id}")
        else:
            console.print(Panel(
                f"[bold yellow]Avertissement:[/bold yellow] Aucun ID trouvé pour '{item_name}' de type '{glpi_itemtype}'.",
                title="[yellow]Résultat de la Recherche[/yellow]"
            ))
            api_client.close_session()
            sys.exit(0)

        console.print("[bold blue]--- DÉBUT RÉCUPÉRATION DÉTAILS ---[/bold blue]")
        details = api_client.get_item_details(glpi_itemtype, item_id)
        console.print("[bold blue]Réponse complète des détails (JSON brut):[/bold blue]")
        print_json(data=details)

    except Exception as e:
        console.print(Panel(
            f"[bold red]Une erreur est survenue:[/bold red] {e}",
            title="[red]Erreur[/red]"
        ))
    finally:
        if api_client.session:
            api_client.close_session()
            console.print("[bold green]Session API fermée.[/bold green]")

if __name__ == "__main__":
    main()


