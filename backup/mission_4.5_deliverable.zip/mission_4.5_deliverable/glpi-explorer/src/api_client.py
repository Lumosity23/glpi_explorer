import requests
import json

class ApiClient:
    def __init__(self, config):
        self.config = config
        self.base_url = config.get("url")
        self.app_token = config.get("app_token")
        self.user_token = config.get("user_token")
        self.session_token = None

    def connect(self):
        headers = {
            "Authorization": f"user_token {self.user_token}",
            "App-Token": self.app_token,
            "Content-Type": "application/json"
        }
        try:
            response = requests.get(f"{self.base_url}/initSession", headers=headers)
            response.raise_for_status()
            session_token = response.json().get("session_token")
            if session_token:
                self.session_token = session_token
                return True
            return False
        except requests.exceptions.RequestException as e:
            print(f"Erreur de connexion: {e}")
            return False

    def close_session(self):
        if not self.session_token:
            return
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
        }
        try:
            requests.get(f"{self.base_url}/killSession", headers=headers)
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la fermeture de session: {e}")


    def search_item(self, itemtype, item_name):
        if not self.session_token:
            return None
            
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
        }

        params = {
            'criteria[0][field]': '1',       # Chercher sur le champ "Nom" (ID 1)
            'criteria[0][searchtype]': 'contains',
            'criteria[0][value]': item_name,
            'forcedisplay[0]': '2'           # FORCER l'affichage du champ "ID de l'objet" (ID 2)
        }
        try:
            response = requests.get(f"{self.base_url}/search/{itemtype}", headers=headers, params=params)
            response.raise_for_status()

            result = response.json()
            
            # Vérifier si la recherche a trouvé quelque chose et si le format est bon
            if isinstance(result, dict) and result.get('totalcount', 0) > 0 and 'data' in result:
                first_item_data = result['data'][0]
                
                # L'ID de l'item est maintenant sous la clé "2", car nous l'avons forcé.
                item_id = first_item_data.get('2')
                
                if item_id:
                    return item_id  # Succès ! On retourne l'ID.
        except (ValueError, KeyError, IndexError):
            # En cas d'erreur de parsing JSON ou de structure de données inattendue
            return None

        # Si on arrive ici, rien n'a été trouvé ou la réponse était mal formée.
        return None

    def get_item_details(self, itemtype, item_id):
        if not self.session_token:
            return None
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
            "Content-Type": "application/json"
        }
        try:
            params = {
                "expand_dropdowns": "true",
                "with_networkports": "true"
            }
            response = requests.get(f"{self.base_url}/{itemtype}/{item_id}", headers=headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la récupération des détails: {e}")
            return None





    def list_items(self, itemtype, item_range="0-4"):
        if not self.session_token:
            return []

        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
            "Content-Type": "application/json"
        }

        params = {
            "range": item_range,
            "expand_dropdowns": "true"
        }
        try:
            response = requests.get(f"{self.base_url}/{itemtype}/", headers=headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la récupération de la liste: {e}")
            return []




