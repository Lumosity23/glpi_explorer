import os
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from src.api_client import ApiClient
from src.config_manager import ConfigManager

class BaseCommand:
    def __init__(self, api_client: ApiClient, console: Console):
        self.api_client = api_client
        self.console = console
        self.TYPE_ALIASES = {
            'computer': 'Computer', 'pc': 'Computer',
            'monitor': 'Monitor', 'screen': 'Monitor',
            'networkequipment': 'NetworkEquipment', 'network': 'NetworkEquipment',
            'switch': 'NetworkEquipment', 'sw': 'NetworkEquipment',
            'hub': 'NetworkEquipment', 'hb': 'NetworkEquipment',
            'peripheral': 'Peripheral',
            'phone': 'Phone',
            'printer': 'Printer',
            'software': 'Software',
            'ticket': 'Ticket',
            'user': 'User',
            'patchpanel': 'PassiveDCEquipment', 'patch': 'PassiveDCEquipment', 'pp': 'PassiveDCEquipment',
            'walloutlet': 'PassiveDCEquipment', 'wo': 'PassiveDCEquipment',
            'cable': 'Cable', 'cb': 'Cable',
        }

    def execute(self, args):
        raise NotImplementedError("Subclasses must implement this method")

    def get_help_message(self):
        raise NotImplementedError("Subclasses must provide a help message")

    def _get_item_type(self, user_type_alias: str) -> str:
        return self.TYPE_ALIASES.get(user_type_alias.lower(), user_type_alias)

    def _display_error(self, message: str):
        self.console.print(Panel(Text(message, style="bold red"), title="[red]Erreur[/red]"))

    def _display_info(self, message: str):
        self.console.print(Panel(Text(message, style="blue"), title="[blue]Information[/blue]"))

    def _display_success(self, message: str):
        self.console.print(Panel(Text(message, style="bold green"), title="[green]Succès[/green]"))

    def _display_warning(self, message: str):
        self.console.print(Panel(Text(message, style="bold yellow"), title="[yellow]Avertissement[/yellow]"))

    def _display_json(self, data):
        self.console.print(Panel(self.console.print_json(data=data), title="[cyan]Détails JSON[/cyan]"))


