## [MISSION 3.1] - 2025-07-08 - par Manus

### Objectif de la Phase

Amélioration de l'affichage des détails pour la commande `get` et enrichissement des données avec les ports réseau.

### Modifications Apportées

- **`src/shell.py`**:
  - Refonte de l'affichage de la commande `get` pour présenter les informations générales et les ports réseau dans des tables `rich` distinctes, encapsulées dans un `Panel` global.
  - Suppression de l'ancienne table clé-valeur.
  - Ajout d'une logique pour vérifier la présence de ports réseau et les afficher si disponibles.


## [MISSION 2.10] - 2025-07-08 - par Manus

### Objectif de la Phase

Correction finale de la méthode de recherche `search_item` pour extraire correctement l'ID de l'objet en se basant sur la réponse réelle de l'API GLPI.

### Modifications Apportées

- **`src/api_client.py`**:
  - Modification des `params` de la requête `search_item` pour inclure `forcedisplay[0]=2`, assurant que l'ID de l'objet est toujours présent dans la réponse.
  - Correction de la logique d'analyse de la réponse JSON pour rechercher la clé `"2"` pour l'ID de l'objet.
  - Ajout d'un bloc `try...except` plus robuste pour gérer les erreurs de parsing JSON ou les structures de données inattendues.


## [MISSION 2.8] - 2025-07-08 - par Manus

### Objectif de la Phase

Correction de la construction de la requête de recherche dans `search_item` pour assurer la compatibilité avec l'API GLPI.

### Modifications Apportées

- **`src/api_client.py`**:
  - Remplacement de la définition du dictionnaire `params` par une liste de tuples pour `search_item` afin de garantir l'ordre et l'encodage correct des clés complexes.
  - Ajout de `forcedisplay[0]=2` pour forcer le retour de l'ID de l'objet.
  - Ajustement de l'analyse de la réponse JSON pour utiliser la structure prévisible avec `forcedisplay`.


## [MISSION 2.7] - 2025-07-08 - par Manus

### Objectif de la Phase

Création d'un script de test API autonome pour diagnostiquer les problèmes de recherche et de listing.

### Modifications Apportées

- **`test_api.py`**: Nouveau script Python autonome pour tester la connexion à l'API GLPI, lister des itemtypes et rechercher des objets spécifiques. Le script utilise `rich` pour des logs clairs et ne nécessite aucune interaction utilisateur.




## [MISSION 2.6] - 2025-07-08 - par Manus

### Objectif de la Phase

Correction des bugs des commandes `list` et `get`.

### Modifications Apportées

- **`src/shell.py`**:
  - Correction des mappings pour `PassiveDevice` vers `PassiveEquipment` pour les alias `patchpanel`, `patch`, `pp`, `walloutlet`, `wo`.
- **`src/api_client.py`**:
  - Refactorisation de la logique d'extraction de l'ID dans `search_item` pour gérer la structure de réponse de l'API GLPI avec `totalcount` et les clés numériques (`'2'`) pour l'ID.


## [MISSION 2.5] - 2025-07-08 - par Manus

### Objectif de la Phase

Amélioration de l'aide contextuelle pour la commande `list` et modernisation du style du tableau de résultats.

### Modifications Apportées

- **`src/shell.py`**: 
  - Ajout d'une aide contextuelle pour la commande `list` lorsqu'elle est appelée sans argument, affichant les types d'objets disponibles et leurs alias dans une table `rich`.
  - Amélioration du style de la table de résultats de la commande `list` en utilisant des bords arrondis (`box.ROUNDED`), un en-tête stylisé (`bold magenta`), et un titre stylisé (`bold blue`).


## [MISSION 2.4] - 2025-07-08 - par Manus

### Objectif de la Phase

Amélioration du shell avec historique des commandes.

### Modifications Apportées

- **`requirements.txt`**: Ajout de la dépendance `prompt-toolkit`.

- **`src/shell.py`**: Remplacement de `rich.console.Console.input()` par `prompt_toolkit.PromptSession` pour offrir un historique des commandes et une meilleure expérience d'édition.

## [MISSION 2.3] - 2025-07-05 - par Manus

### Objectif de la Phase

Correction de la logique d'analyse des arguments pour la commande `get` afin de séparer correctement le type d'objet de son nom.

### Modifications Apportées

- **`src/shell.py`**: Refonte de la logique de parsing des arguments pour la commande `get`. Utilisation de `split(maxsplit=1)` pour extraire le type et le nom de l'objet, même si le nom contient des espaces. Ajout de validations pour les arguments manquants et les types d'objets inconnus.

## [MISSION 2.2.1] - 2025-07-05 - par Manus

### Objectif de la Phase

Correction d'une `SyntaxError` dans `src/shell.py` due à un bloc `try...except` mal structuré.

### Modifications Apportées

- **`src/shell.py`**: Restauration de la structure `try...except` correcte dans la méthode `run()` pour assurer la bonne exécution de l'application. Le bloc `except EOFError:` a été réaligné correctement avec le bloc `try`.

## [MISSION 2.2] - 2025-07-05 - par Manus

### Objectif de la Phase

Implémentation de la commande `list <type>` pour lister les équipements GLPI avec pagination par défaut.

### Modifications Apportées

- **`src/api_client.py`**:
  - Ajout d'une nouvelle méthode `list_items(self, itemtype, item_range="0-4")` pour effectuer des requêtes GET paginées vers le endpoint `/apirest.php/{itemtype}/`.
  - La méthode inclut les paramètres `range` et `expand_dropdowns`.

- **`src/shell.py`**:
  - Ajout de la gestion de la commande `list` dans la méthode `run()`.
  - Validation de la présence de l'argument `<type>`.
  - Utilisation de `TYPE_ALIASES` pour traduire l'alias utilisateur en `itemtype` GLPI.
  - Appel de la méthode `api_client.list_items` pour récupérer les données.
  - Affichage des résultats dans une `rich.table.Table` avec les colonnes "ID", "Nom" et "Statut", encapsulée dans un `Panel`.

## [MISSION 2.1] - 2025-07-05 - par Manus

### Objectif de la Phase

Refonte de la commande `get` pour exiger la spécification du type d'objet, simplifiant la logique de recherche et augmentant la fiabilité.

### Modifications Apportées

- **`src/shell.py`**:
  - La commande `get` accepte désormais deux arguments : le type et le nom de l'objet (`get <type> <nom_objet>`).
  - Ajout d'une validation pour s'assurer que deux arguments sont fournis, avec un message d'erreur clair si ce n'est pas le cas.
  - Implémentation d'un dictionnaire `TYPE_ALIASES` pour mapper les alias utilisateur (`computer`, `pc`, etc.) aux `itemtypes` GLPI réels (`Computer`, `NetworkEquipment`, etc.).
  - Validation de l'alias de type fourni par l'utilisateur.
  - Adaptation de l'appel à `api_client.search_item` pour utiliser le `itemtype` et le `item_name` extraits.

- **`src/api_client.py`**:
  - Renommage de la méthode `search_item_by_name` en `search_item`.
  - Modification de la signature de `search_item` pour accepter `itemtype` et `item_name`.
  - Suppression de la boucle interne qui itérait sur différents types d'objets ; la méthode effectue désormais une seule requête sur l' `itemtype` fourni.
  - La méthode `search_item` retourne maintenant uniquement l'ID de l'item trouvé, ou `None`.

## [MISSION 1.6] - 2024-07-05 - par Manus

### Objectif de la Phase

Refactorisation de la méthode de recherche d'items pour aligner la logique sur l'ancienne méthode fonctionnelle.

### Modifications Apportées

- **`src/api_client.py`**:
  - Modifié la méthode `search_item_by_name` pour utiliser les noms de champs littéraux (`'name'`) au lieu des ID numériques dans les critères de recherche.
  - Amélioré l'analyse de la réponse JSON pour gérer les cas où la clé `data` est présente ou lorsque la réponse est directement une liste, assurant une robustesse accrue face aux variations de l'API.

## [MISSION 1.5] - 2024-07-05 - par Manus

### Objectif de la Phase

Correction de la logique de configuration et de la méthode de recherche API.

### Modifications Apportées

- **`src/api_client.py`**:
  - Corrigé le nom de la clé de configuration de `api_url` à `url`.
  - Corrigé l'en-tête d'authentification pour utiliser `Session-Token` au lieu de `Authorization` pour les requêtes post-connexion.
  - Réécriture complète de la méthode `search_item_by_name` pour qu'elle itère sur les `itemtypes` et interroge le bon endpoint (`/apirest.php/{itemtype}/`) conformément à la documentation de l'API.

## [MISSION 1.4] - 2024-07-05 - par Manus

### Objectif de la Phase

Fiabiliser le chargement de la configuration pour gérer les fichiers corrompus ou incomplets.

### Modifications Apportées

- **`src/shell.py`**: Refonte de la logique de démarrage. L'application ne vérifie plus seulement l'existence du fichier de configuration, mais aussi sa validité (présence et contenu des clés `url`, `app_token`, `user_token`). Si la configuration est invalide, l'assistant de configuration est automatiquement relancé. Ajout d'une méthode d'aide privée `_is_config_valid` pour encapsuler cette logique.

## [MISSION 1.3] - 2024-07-05 - par Manus

### Objectif de la Phase

Refactoring du client API pour une gestion correcte et encapsulée du `session_token`.

### Modifications Apportées

- **`src/api_client.py`**: Le fichier a été entièrement réécrit pour avoir une seule classe `ApiClient` propre. La classe gère maintenant son propre `session_token` en interne après une connexion réussie. Les méthodes n'ont plus besoin de recevoir le token en paramètre.

- **`src/shell.py`**: Mise à jour de toute la logique pour s'adapter au nouveau `ApiClient`. Le `session_token` n'est plus géré par le shell mais par le client API. La logique de connexion, de test, d'appel des commandes et de déconnexion a été simplifiée.

## [MISSION 1.2] - 2024-07-05 - par Manus

### Objectif de la Phase

Fiabiliser le shell contre les entrées vides et améliorer la robustesse de la commande `get`.

### Modifications Apportées

- **`src/shell.py`**: Ajout d'une vérification pour ignorer les entrées vides, prévenant ainsi le crash `IndexError`. Amélioration de l'affichage des détails pour extraire les noms lisibles du statut et de la localisation.

- **`src/api_client.py`**: Modification de la méthode de recherche pour utiliser `searchtype="contains"` au lieu de `"equals"`, rendant la recherche d'objets plus flexible et efficace.

## [CORRECTION] - 2024-07-05 - par Manus

### Objectif de la Phase

Correction des erreurs de syntaxe dans `src/shell.py`.

### Modifications Apportées

- **`src/shell.py`**: Correction des f-strings non terminées aux lignes 67 et 73 pour résoudre le `SyntaxError: unterminated f-string literal`.

## [MISSION 1.1] - 2024-07-04 - par Manus

### Objectif de la Phase

Implémenter la première commande fonctionnelle `get <nom_objet>` pour rechercher un équipement et afficher ses détails de base.

### Modifications Apportées

- **`src/api_client.py`**: Ajout des méthodes `search_item_by_name` et `get_item_details` pour interagir avec les endpoints de recherche et de récupération d'items de GLPI, en se basant sur la documentation de l'API fournie.

- **`src/shell.py`**: Mise à jour de la boucle principale pour analyser les commandes utilisateur. Implémentation de la logique pour la commande `get`, incluant la recherche, la récupération des détails et l'affichage formaté des résultats dans un `Panel` et une `Table` `rich`.

## [MISSION 0.3.1] - 2024-07-04 - par Manus

### Objectif de la Phase

Correction et fiabilisation de la connexion API et du processus de configuration.

### Modifications Apportées

- **Correction (Mission 0.3.1)**: Fiabilisation du client API, suppression du code en double, et amélioration de la gestion des erreurs de connexion.

## [MISSION 0.3] - 2024-05-24 - par Manus

### Objectif de la Phase

Remplacer la configuration par fichier .env par un processus de configuration interactif et persistant au premier lancement de l'application.

### Modifications Apportées

- **`requirements.txt`**: Suppression de `python-dotenv`.

- **`src/config_manager.py`**: Création du module pour gérer la lecture, l'écriture et la collecte interactive des informations de configuration dans `~/.config/glpi-explorer/config.json`.

- **`src/api_client.py`**: Mise à jour de la classe `ApiClient` pour qu'elle soit initialisée avec un dictionnaire de configuration et pour qu'elle retourne des informations plus détaillées sur l'échec/succès de la connexion.

- **`src/shell.py`**: Refonte majeure de la logique de démarrage pour gérer le flux de configuration : vérifier si la configuration existe, lancer l'assistant interactif si nécessaire, tester et sauvegarder la configuration, puis se connecter à l'API.

## [MISSION 0.2] - 2024-05-24 - par Manus

### Objectif de la Phase

Intégrer la logique de connexion à l'API REST de GLPI, en utilisant un fichier de configuration .env pour les identifiants et en gérant le cycle de vie de la session (init/kill).

### Modifications Apportées

- **`.env.example`**: Création d'un fichier d'exemple pour les variables de configuration de l'API.

- **`requirements.txt`**: Ajout de la dépendance `requests`.

- **`src/config.py`**: Création du module pour charger et valider la configuration depuis le fichier `.env`.

- **`src/api_client.py`**: Implémentation de la classe `ApiClient` avec les méthodes `connect()` et `close_session()`.

- **`src/shell.py`**: Mise à jour du shell pour initier la connexion au démarrage, gérer les échecs et fermer la session en quittant.

## [MISSION 0.1] - 2024-05-24 - par Manus

### Objectif de la Phase

Mise en place du socle de l'application CLI interactive, de sa structure de fichiers et de sa boucle de commande principale.

### Modifications Apportées

- **`glpi-explorer/`**: Création de l'arborescence initiale du projet.

- **`requirements.txt`**: Ajout des dépendances `rich` et `python-dotenv`.

- **`.gitignore`**: Configuration initiale pour les projets Python.

- **`main.py`**: Création du point d'entrée qui lance le shell interactif.

- **`src/shell.py`**: Implémentation de la classe `GLPIExplorerShell` avec une boucle de commande, un message de bienvenue, un prompt stylisé et la logique pour quitter (`exit`/`quit`).















## [MISSION 3.2] - 2025-07-08 - par Manus

### Objectif de la Phase

Implémentation d'une commande `debug` pour le shell, permettant de visualiser les requêtes et réponses API pour les commandes spécifiques, en commençant par la commande `get`.

### Modifications Apportées

- **`src/api_client.py`**:
  - Ajout d'un paramètre `debug=False` aux méthodes `get_item_details` et `search_item`.
  - Modification de ces méthodes pour retourner les informations de débogage (détails de la requête et de la réponse) en plus du résultat principal lorsque `debug` est `True`.

- **`src/shell.py`**:
  - Refactorisation de la logique de la commande `get` dans une nouvelle méthode `handle_get_command(self, args, debug=False)`.
  - Ajout d'une nouvelle commande `debug` qui accepte une sous-commande (ex: `debug get <type> <nom_objet>`).
  - La commande `debug get` appelle `handle_get_command` avec `debug=True`, affichant les informations de débogage de l'API.
  - La commande `get` normale appelle `handle_get_command` avec `debug=False`.
  - Suppression de l'ancienne logique de la commande `get` de la méthode `run` pour éviter la duplication et améliorer la modularité.

