import requests
from src.config import API_URL, APP_TOKEN, USER_TOKEN

class ApiClient:
    def __init__(self):
        self.session_token = None

    def connect(self):
        init_session_url = f"{API_URL}/initSession"
        headers = {
            'Content-Type': 'application/json',
            'App-Token': APP_TOKEN,
            'Authorization': f'user_token {USER_TOKEN}'
        }
        try:
            response = requests.get(init_session_url, headers=headers)
            if response.status_code == 200:
                self.session_token = response.json().get('session_token')
                return True
            else:
                return False
        except requests.exceptions.RequestException:
            return False

    def close_session(self):
        if self.session_token:
            kill_session_url = f"{API_URL}/killSession"
            headers = {
                'App-Token': APP_TOKEN,
                'Session-Token': self.session_token
            }
            try:
                requests.get(kill_session_url, headers=headers)
            except requests.exceptions.RequestException:
                pass



import requests

class ApiClient:
    def __init__(self, config):
        self.config = config
        self.base_url = self.config["url"]
        self.app_token = self.config["app_token"]
        self.user_token = self.config["user_token"]

    def connect(self):
        headers = {
            "App-Token": self.app_token,
            "Authorization": f"user_token {self.user_token}"
        }
        try:
            response = requests.get(f"{self.base_url}/initSession", headers=headers)
            response.raise_for_status()  # Lève une exception pour les codes d'état HTTP d'erreur
            session_token = response.json().get("session_token")
            if session_token:
                return True, session_token
            else:
                return False, "Session token non reçu."
        except requests.exceptions.RequestException as e:
            return False, f"Erreur de connexion à l'API : {e}"

    def close_session(self, session_token):
        headers = {
            "App-Token": self.app_token,
            "Session-Token": session_token
        }
        try:
            requests.get(f"{self.base_url}/killSession", headers=headers)
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la fermeture de la session : {e}")


