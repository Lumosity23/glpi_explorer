from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from src.api_client import ApiClient
from src.config_manager import ConfigManager

class GLPIExplorerShell:
    def __init__(self):
        self.console = Console()
        self.api_client = None
        self.session_token = None

    def run(self):
        config_manager = ConfigManager()
        config = config_manager.load_config()

        if config is None:
            self.console.print(Panel("[bold blue]Bienvenue dans GLPI Explorer ![/bold blue]\n\n[yellow]Il semble que ce soit votre première utilisation ou que la configuration précédente soit manquante.\nNous allons vous guider à travers le processus de configuration.[/yellow]", expand=False))
            while True:
                config = config_manager.run_setup_interactive()
                api_client_test = ApiClient(config)
                with self.console.status("[bold green]Test de la connexion API...[/bold green]"):
                    is_connected, message = api_client_test.connect()

                if not is_connected:
                    self.console.print(Panel(f"[bold red]Échec de la connexion :[/bold red] {message}\n[yellow]Veuillez réessayer avec des informations valides.[/yellow]", title="[red]Erreur de Connexion[/red]"))
                else:
                    config_manager.save_config(config)
                    self.console.print(Panel("[bold green]Configuration sauvegardée avec succès et connexion testée ![/bold green]", title="[green]Succès[/green]"))
                    # Close the test session if it was successful
                    if message: # message contains session_token if connected
                        api_client_test.close_session(message)
                    break

        # Logique de connexion principale
        self.api_client = ApiClient(config)
        with self.console.status("[bold green]Connexion à l'API GLPI...[/bold green]"):
            is_connected, message = self.api_client.connect()

        if not is_connected:
            self.console.print(Panel(f"[bold red]Échec de la connexion principale :[/bold red] {message}\n[yellow]Veuillez vérifier votre configuration ou relancer l'application pour reconfigurer.[/yellow]", title="[red]Erreur[/red]"))
            return
        else:
            self.session_token = message # message is the session_token here

        self.console.print(Panel("Bienvenue dans GLPI Explorer", title="[bold cyan]GLPI Explorer[/]", subtitle="[green]v0.1[/]"))

        while True:
            try:
                command = self.console.input("[bold cyan](glpi-explorer)> [/]").strip().lower()
                if command in ("exit", "quit"):
                    if self.api_client and self.session_token:
                        self.api_client.close_session(self.session_token)
                    break
            except EOFError:
                if self.api_client and self.session_token:
                    self.api_client.close_session(self.session_token)
                break

        self.console.print("[yellow]Au revoir ![/yellow]")


