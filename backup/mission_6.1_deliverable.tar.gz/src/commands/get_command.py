from src.commands.base_command import BaseCommand
from rich.table import Table
from rich.panel import Panel
from rich.console import Group
from rich.text import Text
from rich import box
from src.api_client import ApiClient

class GetCommand(BaseCommand):
    def execute(self, args):
        if not args:
            self.console.print(Panel("[bold red]Erreur:[/bold red] La commande 'get' nécessite deux arguments.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
            return
        
        try:
            user_type_alias, item_name = args.split(maxsplit=1)
        except ValueError:
            self.console.print(Panel("[bold red]Erreur:[/bold red] Syntaxe incorrecte. Il manque soit le type, soit le nom de l'objet.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
            return

        glpi_itemtype = self.TYPE_ALIASES.get(user_type_alias.lower())
        
        if not glpi_itemtype:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Le type '{user_type_alias}' est inconnu.", title="[red]Type Inconnu[/red]"))
            return
        
        with self.console.status(f"Récupération de la liste des '{glpi_itemtype}'..."):
            # On demande tous les items du type donné
            all_items = self.api_client.list_items(glpi_itemtype, item_range="0-9999")

        if not all_items:
            self.console.print(Panel(f"Aucun objet de type '{user_type_alias}' trouvé dans GLPI.", title="[blue]Information[/blue]", border_style="blue"))
            return

        # Recherche de l'item par son nom dans la liste reçue
        found_item = None
        for item in all_items:
            # On peut rendre la comparaison insensible à la casse pour plus de flexibilité
            if item.get("name", "").lower() == item_name.lower():
                found_item = item
                break
        
        if found_item is None:
            self.console.print(Panel(f"Erreur: Aucun objet de type '{user_type_alias}' nommé '{item_name}' trouvé.", title="[red]Non trouvé[/red]"))
            return

        # On a trouvé l'item, on a son ID
        item_id = found_item.get("id")

        with self.console.status(f"Récupération des détails de {item_name}..."):
            details = self.api_client.get_item_details(glpi_itemtype, item_id)
        
        if details:
            # Création d'une table unique pour tous les détails
            table = Table(title=f"Détails de {details.get('name', item_name)}", box=box.ROUNDED, show_header=False)
            table.add_column("Attribut", style="cyan")
            table.add_column("Valeur")

            # Ajout des informations générales
            table.add_row("ID", str(details.get("id")))
            table.add_row("Nom", details.get("name"))
            table.add_row("Type GLPI", glpi_itemtype)
            table.add_row("Statut", str(details.get("states_id", "N/A")))
            table.add_row("Localisation", str(details.get("locations_id", "N/A")))
            table.add_row("Fabricant", str(details.get("manufacturers_id", "N/A")))

            # Ajout d'une section pour les ports
            table.add_section()

            # Traitement des ports réseau
            network_ports_data = details.get("_networkports", {})
            if network_ports_data:
                for port_type, port_list in network_ports_data.items():
                    if port_list:
                        for port in port_list:
                            port_details_str = (
                                f"Type: {port_type}\n"
                                f"MAC: {port.get('mac', 'N/A')}\n"
                                f"Vitesse: {port.get('speed', 'N/A')} Mbps\n"
                                f"Connecté à: [italic]Non implémenté[/italic]"
                            )
                            table.add_row(f"[bold]{port.get('name')}[/bold]", port_details_str)
            else:
                table.add_row("[bold]Ports Réseau[/bold]", "Aucun port réseau trouvé pour cet équipement.")

            # Affichage de la table dans un Panel
            self.console.print(Panel(table, title=f"[bold blue]Détails de {item_name}[/bold blue]", expand=False))
        else:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Impossible de récupérer les détails pour '{item_name}'.", title="[red]Erreur[/red]"))

