
import requests
import json

class ApiClient:
    def __init__(self, config):
        self.config = config
        self.base_url = config.get("url")
        self.app_token = config.get('app_token')
        self.user_token = config.get('user_token')
        self.session_token = None

    def connect(self):
        headers = {
            'Authorization': f'user_token {self.user_token}',
            'App-Token': self.app_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.get(f'{self.base_url}/initSession', headers=headers)
            response.raise_for_status()
            session_token = response.json().get('session_token')
            if session_token:
                self.session_token = session_token
                return True
            return False
        except requests.exceptions.RequestException as e:
            print(f"Erreur de connexion: {e}")
            return False

    def close_session(self):
        if not self.session_token:
            return
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
        }
        try:
            requests.get(f'{self.base_url}/killSession', headers=headers)
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la fermeture de session: {e}")


    def search_item_by_name(self, item_name):
        if not self.session_token:
            return None, None
            
        item_types_to_search = ["Computer", "NetworkEquipment", "PassiveDevice"]
        
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
        }

        for itemtype in item_types_to_search:
            params = {
                "criteria[0][field]": 2,  # Champ "Nom"
                "criteria[0][searchtype]": "contains",
                "criteria[0][value]": item_name,
                "forcedisplay[0]": 1 # Pour forcer l'affichage de l'ID, juste au cas où
            }
            try:
                response = requests.get(f"{self.base_url}/search/{itemtype}", headers=headers, params=params)
                response.raise_for_status()
                result = response.json()
                # La réponse peut être un dict avec 'data' ou une liste directe si un seul résultat
                data = result.get("data", result if isinstance(result, list) else [])
                
                if data:
                    # L'ID est la clé 1 dans la réponse de la recherche
                    item_id = data[0].get("1")
                    if item_id:
                        return itemtype, item_id
            except requests.exceptions.RequestException:
                # Si une recherche échoue pour un type, on continue avec le suivant
                continue
        
        return None, None

    def get_item_details(self, itemtype, item_id):
        if not self.session_token:
            return None
        headers = {
            "Session-Token": self.session_token,
            "App-Token": self.app_token,
            "Content-Type": "application/json"
        }
        try:
            response = requests.get(f'{self.base_url}/{itemtype}/{item_id}', headers=headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la récupération des détails: {e}")
            return None


