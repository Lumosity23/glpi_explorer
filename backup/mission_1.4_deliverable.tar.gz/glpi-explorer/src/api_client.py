
import requests
import json

class ApiClient:
    def __init__(self, config):
        self.config = config
        self.base_url = config.get('api_url')
        self.app_token = config.get('app_token')
        self.user_token = config.get('user_token')
        self.session_token = None

    def connect(self):
        headers = {
            'Authorization': f'user_token {self.user_token}',
            'App-Token': self.app_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.get(f'{self.base_url}/initSession', headers=headers)
            response.raise_for_status()
            session_token = response.json().get('session_token')
            if session_token:
                self.session_token = session_token
                return True
            return False
        except requests.exceptions.RequestException as e:
            print(f"Erreur de connexion: {e}")
            return False

    def close_session(self):
        if not self.session_token:
            return
        headers = {
            'Authorization': f'session_token {self.session_token}',
            'App-Token': self.app_token,
        }
        try:
            requests.get(f'{self.base_url}/killSession', headers=headers)
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la fermeture de session: {e}")

    def search_item_by_name(self, item_name):
        if not self.session_token:
            return None, None
        headers = {
            'Authorization': f'session_token {self.session_token}',
            'App-Token': self.app_token,
            'Content-Type': 'application/json'
        }
        params = {'searchText': item_name}
        try:
            response = requests.get(f'{self.base_url}/search', headers=headers, params=params)
            response.raise_for_status()
            data = response.json()
            if data and data.get('data'):
                for item_type, items in data['data'].items():
                    if items:
                        return item_type, items[0]['id']
            return None, None
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la recherche: {e}")
            return None, None

    def get_item_details(self, itemtype, item_id):
        if not self.session_token:
            return None
        headers = {
            'Authorization': f'session_token {self.session_token}',
            'App-Token': self.app_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.get(f'{self.base_url}/{itemtype}/{item_id}', headers=headers)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de la récupération des détails: {e}")
            return None


