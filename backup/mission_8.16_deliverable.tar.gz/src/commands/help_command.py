from src.commands.base_command import BaseCommand
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

class HelpCommand(BaseCommand):
    def __init__(self, api_client, console, commands_map):
        super().__init__(api_client, console)
        self.commands_map = commands_map

    def execute(self, args):
        # Table for main commands
        commands_table = Table(title="Commandes Disponibles", show_header=True, header_style="bold magenta")
        commands_table.add_column("Commande")
        commands_table.add_column("Description")
        commands_table.add_column("Usage")

        # Define aliases and their base commands
        aliases = {
            "ls": "list",
            "q": "exit",
            "cp": "compare"
        }
        # Create a set of base commands that have aliases to avoid duplicating their full help message
        aliased_base_commands = set(aliases.values())

        # Populate commands table
        for cmd_name, cmd_instance in self.commands_map.items():
            if cmd_name not in aliased_base_commands and cmd_name not in aliases.keys():
                try:
                    help_message = cmd_instance.get_help_message()
                    commands_table.add_row(cmd_name, help_message["description"], help_message["usage"])
                except Exception as e:
                    self.console.print(f"[bold red]Erreur lors de la récupération de l'aide pour {cmd_name}: {e}[/bold red]")
                    commands_table.add_row(cmd_name, "N/A", "N/A")

        # Table for aliases
        aliases_table = Table(title="Alias de Commandes", show_header=True, header_style="bold yellow")
        aliases_table.add_column("Alias")
        aliases_table.add_column("Description")
        aliases_table.add_column("Usage")

        # Populate aliases table
        aliases_table.add_row("cp", "Alias pour la commande 'compare'", "cp <type1> <nom1> with <type2> <nom2>")
        aliases_table.add_row("ls", "Alias pour la commande 'list'", "ls <type>")
        aliases_table.add_row("q", "Alias pour la commande 'exit'", "q")

        # Print both tables within panels
        self.console.print(Panel(commands_table, title="[bold blue]Aide GLPI Explorer[/bold blue]"))
        self.console.print(Panel(aliases_table, title="[bold yellow]Alias[/bold yellow]"))

    def get_help_message(self):
        return {
            "description": "Affiche ce message d'aide.",
            "usage": "help"
        }
