
from rich.console import Console
from rich.panel import Panel
from src.api_client import ApiClient

class GLPIExplorerShell:
    def __init__(self):
        self.console = Console()

    def run(self):
        api_client = ApiClient()

        with self.console.status("[bold green]Connexion à l'API GLPI..."):
            is_connected = api_client.connect()

        if not is_connected:
            self.console.print(Panel("[bold red]Échec de la connexion.[/bold red] Veuillez vérifier votre configuration (.env) et l'accès à GLPI.", title="[red]Erreur[/red]"))
            return

        self.console.print(Panel("Bienvenue dans GLPI Explorer", title="[bold cyan]GLPI Explorer[/]", subtitle="[green]v0.1[/]"))

        while True:
            try:
                command = self.console.input("[bold cyan](glpi-explorer)> [/]").strip().lower()
                if command in ("exit", "quit"):
                    api_client.close_session()
                    break
            except EOFError:
                api_client.close_session()
                break

        self.console.print("[yellow]Au revoir ![/yellow]")



