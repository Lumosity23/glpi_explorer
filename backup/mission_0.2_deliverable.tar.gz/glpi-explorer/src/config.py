import os
from dotenv import load_dotenv

load_dotenv()

API_URL = os.getenv("GLPI_API_URL")
APP_TOKEN = os.getenv("GLPI_APP_TOKEN")
USER_TOKEN = os.getenv("GLPI_USER_TOKEN")

if not API_URL:
    raise ValueError("La variable d'environnement GLPI_API_URL est manquante.")
if not APP_TOKEN:
    raise ValueError("La variable d'environnement GLPI_APP_TOKEN est manquante.")
if not USER_TOKEN:
    raise ValueError("La variable d'environnement GLPI_USER_TOKEN est manquante.")


