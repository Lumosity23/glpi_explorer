import requests
from src.config import API_URL, APP_TOKEN, USER_TOKEN

class ApiClient:
    def __init__(self):
        self.session_token = None

    def connect(self):
        init_session_url = f"{API_URL}/initSession"
        headers = {
            'Content-Type': 'application/json',
            'App-Token': APP_TOKEN,
            'Authorization': f'user_token {USER_TOKEN}'
        }
        try:
            response = requests.get(init_session_url, headers=headers)
            if response.status_code == 200:
                self.session_token = response.json().get('session_token')
                return True
            else:
                return False
        except requests.exceptions.RequestException:
            return False

    def close_session(self):
        if self.session_token:
            kill_session_url = f"{API_URL}/killSession"
            headers = {
                'App-Token': APP_TOKEN,
                'Session-Token': self.session_token
            }
            try:
                requests.get(kill_session_url, headers=headers)
            except requests.exceptions.RequestException:
                pass


