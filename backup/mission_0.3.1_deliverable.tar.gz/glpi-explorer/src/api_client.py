import requests

class ApiClient:
    def __init__(self, config):
        self.config = config
        self.base_url = self.config["url"]
        self.app_token = self.config["app_token"]
        self.user_token = self.config["user_token"]

    def connect(self):
        headers = {
            "App-Token": self.app_token,
            "Authorization": f"user_token {self.user_token}"
        }
        try:
            response = requests.get(f"{self.base_url}/initSession", headers=headers)
            response.raise_for_status()  # Lève une exception pour les codes d'état HTTP d'erreur
            session_token = response.json().get("session_token")
            if session_token:
                return True, session_token
            else:
                return False, "Session token non reçu."
        except requests.exceptions.HTTPError as e:
            return False, f"Erreur HTTP : {e.response.status_code} - {e.response.reason}"
        except requests.exceptions.ConnectionError:
            return False, f"Erreur de connexion. Impossible de joindre l\"URL : {self.base_url}"
        except requests.exceptions.RequestException as e:
            return False, f"Erreur de requête non spécifiée : {e}"

    def close_session(self, session_token):
        headers = {
            "App-Token": self.app_token,
            "Session-Token": session_token
        }
        try:
            requests.get(f"{self.base_url}/killSession", headers=headers)
        except requests.exceptions.RequestException:
            pass


