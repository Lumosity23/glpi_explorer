# src/commands/base_command.py

# Ces imports ne sont plus nécessaires ici car ils sont gérés
# par les classes de commande individuelles ou passés via __init__.
# from src.api_client import ApiClient
# from src.config_manager import ConfigManager

class BaseCommand:
    def __init__(self, api_client, console):
        """
        Initialise la commande de base.
        
        Args:
            api_client: Une instance du client API déjà connecté.
            console: Une instance de la console Rich pour l'affichage.
        """
        self.api_client = api_client
        self.console = console
        self.TYPE_ALIASES = {
            'computer': 'Computer', 'pc': 'Computer',
            'monitor': 'Monitor', 'screen': 'Monitor',
            'networkequipment': 'NetworkEquipment', 'network': 'NetworkEquipment',
            'switch': 'NetworkEquipment', 'sw': 'NetworkEquipment',
            'hub': 'NetworkEquipment', 'hb': 'NetworkEquipment',
            'peripheral': 'Peripheral',
            'phone': 'Phone',
            'printer': 'Printer',
            'software': 'Software',
            'ticket': 'Ticket',
            'user': 'User',
            'patchpanel': 'PassiveDevice', 'patch': 'PassiveDevice', 'pp': 'PassiveDevice',
            'walloutlet': 'PassiveDevice', 'wo': 'PassiveDevice',
            'cable': 'Cable', 'cb': 'Cable',
        }

    def execute(self, args):
        """
        La méthode principale que chaque sous-classe de commande doit implémenter.
        
        Args:
            args (str): La chaîne d'arguments qui suit le nom de la commande.
        """
        raise NotImplementedError("La méthode execute() doit être implémentée par la sous-classe.")