from rich.console import Console
from rich.panel import Panel
from src.api_client import ApiClient
from src.config_manager import ConfigManager
from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.formatted_text import FormattedText
import importlib
import os

class GLPIExplorerShell:
    def __init__(self):
        self.console = Console()
        self.api_client = None
        self.history = InMemoryHistory()
        self.prompt_session = PromptSession(history=self.history)
        self.commands = {}
        self._load_commands()

    def _load_commands(self):
        commands_dir = os.path.join(os.path.dirname(__file__), 'commands')
        for filename in os.listdir(commands_dir):
            if filename.endswith('_command.py') and filename != 'base_command.py':
                module_name = filename[:-3]
                command_name = module_name.replace('_command', '')
                try:
                    module = importlib.import_module(f'src.commands.{module_name}')
                    class_name = ''.join(word.capitalize() for word in command_name.split('_')) + 'Command'
                    command_class = getattr(module, class_name)
                    self.commands[command_name] = command_class
                except Exception as e:
                    self.console.print(f"[bold red]ERREUR CRITIQUE LORS DU CHARGEMENT DE LA COMMANDE '{command_name}'[/bold red]")
                    self.console.print_exception(show_locals=True) # Affiche une traceback riche et détaillée
                    self.console.print(Panel(f"L'erreur de type '{type(e).__name__}' empêche le chargement. Voir la traceback ci-dessus.", title=f"[bold red]Échec Chargement Commande: {command_name}[/bold red]", border_style="red"))

    def _is_config_valid(self, config):
        if not isinstance(config, dict):
            return False
        required_keys = ["url", "app_token", "user_token"]
        for key in required_keys:
            if key not in config or not config[key]:
                return False
        return True

    def run(self):
        config_manager = ConfigManager()
        config = config_manager.load_config()

        if not self._is_config_valid(config):
            self.console.print(Panel("[bold blue]Bienvenue... ou la configuration est invalide.[/bold blue]\n[yellow]Il semble que ce soit votre première utilisation ou que la configuration précédente soit manquante ou corrompue.\nNous allons vous guider à travers le processus de configuration.[/yellow]", expand=False))
            while True:
                config = config_manager.run_setup_interactive()
                api_client_test = ApiClient(config)
                with self.console.status("[bold green]Test de la connexion API...[/bold green]"):
                    is_connected = api_client_test.connect()

                if not is_connected:
                    self.console.print(Panel(f"[bold red]Échec de la connexion :[/bold red] Veuillez réessayer avec des informations valides.", title="[red]Erreur de Connexion[/red]"))
                else:
                    api_client_test.close_session()
                    config_manager.save_config(config)
                    self.console.print(Panel("[bold green]Configuration sauvegardée avec succès ![/bold green]", title="[green]Succès[/green]"))
                    break

        self.api_client = ApiClient(config)
        with self.console.status("[bold green]Connexion à l'API GLPI...[/bold green]"):
            is_connected = self.api_client.connect()

        if not is_connected:
            self.console.print(Panel(f"[bold red]Échec de la connexion principale :[/bold red] Veuillez vérifier votre configuration ou relancer l'application pour reconfigurer.", title="[red]Erreur[/red]"))
            return

        self.console.print(Panel("Bienvenue dans GLPI Explorer", title="[bold cyan]GLPI Explorer[/]", subtitle="[green]v0.1[/]"))

        while True:
            try:
                prompt_message = FormattedText([
                    ('bold cyan', '(glpi-explorer)> ')
                ])
                
                full_command = self.prompt_session.prompt(prompt_message).strip()

                if not full_command:
                    continue
                parts = full_command.split(maxsplit=1)
                command_name = parts[0].lower()
                args = parts[1] if len(parts) > 1 else ""

                if command_name in self.commands:
                    command_instance = self.commands[command_name](self.api_client, self.console)
                    command_instance.execute(args)
                elif command_name in ("exit", "quit"):
                    if self.api_client:
                        self.api_client.close_session()
                    break
                else:
                    self.console.print(Panel(f"[bold red]Commande inconnue:[/bold red] \'{command_name}\'. Commandes supportées: {', '.join(self.commands.keys())}, exit, quit", title="[red]Erreur[/red]"))

            except EOFError:
                if self.api_client:
                    self.api_client.close_session()
                break




