import sys
import json
from rich.console import Console
from rich.panel import Panel
from rich import print_json

# Assurez-vous que le chemin vers src est dans sys.path
sys.path.insert(0, './src')

from src.api_client import ApiClient
from src.config_manager import ConfigManager

console = Console()

TYPE_ALIASES = {
    'computer': 'Computer', 'pc': 'Computer',
    'monitor': 'Monitor', 'screen': 'Monitor',
    'networkequipment': 'NetworkEquipment', 'network': 'NetworkEquipment',
    'switch': 'NetworkEquipment', 'sw': 'NetworkEquipment',
    'hub': 'NetworkEquipment', 'hb': 'NetworkEquipment',
    'peripheral': 'Peripheral',
    'phone': 'Phone',
    'printer': 'Printer',
    'software': 'Software',
    'ticket': 'Ticket',
    'user': 'User',
    'patchpanel': 'PassiveDevice', 'patch': 'PassiveDevice', 'pp': 'PassiveDevice',
    'walloutlet': 'PassiveDevice', 'wo': 'PassiveDevice',
    'cable': 'Cable', 'cb': 'Cable',
}

def _get_item_type(user_type_alias: str) -> str:
    return TYPE_ALIASES.get(user_type_alias.lower(), user_type_alias)

def main():
    if len(sys.argv) != 3:
        console.print(Panel(
            "[bold red]Erreur:[/bold red] Utilisation: python api_diagnostic.py <type> <nom_objet>",
            title="[red]Utilisation[/red]"
        ))
        sys.exit(1)

    user_type_alias = sys.argv[1]
    item_name = sys.argv[2]

    config_manager = ConfigManager()
    config = config_manager.load_config()

    if not config:
        console.print(Panel(
            "[bold red]Erreur:[/bold red] Configuration GLPI introuvable. Veuillez exécuter l'application principale pour la configurer.",
            title="[red]Erreur de Configuration[/red]"
        ))
        sys.exit(1)

    api_client = ApiClient(config)
    is_connected = False
    try:
        console.print("[bold blue]--- CONNEXION À L'API GLPI ---[/bold blue]")
        if not api_client.connect():
            console.print("[bold red]Échec de la connexion.[/bold red]")
            sys.exit(1)
        
        is_connected = True
        console.print("[bold green]Connexion réussie.[/bold green]")

        glpi_itemtype = _get_item_type(user_type_alias)

        console.print(f"[bold blue]--- RECHERCHE DE '{item_name}' DANS '{glpi_itemtype}' ---[/bold blue]")
        
        all_items = api_client.list_items(glpi_itemtype, item_range="0-9999")

        if not all_items:
            console.print(Panel(f"Aucun objet de type '{glpi_itemtype}' trouvé.", title="[yellow]Information[/yellow]"))
            sys.exit(0)

        console.print(f"[bold blue]Réponse de list_items (les 5 premiers objets sur {len(all_items)}):[/bold blue]")
        print_json(data=all_items[:5])

        found_item = None
        for item in all_items:
            if item.get("name", "").lower() == item_name.lower():
                found_item = item
                break
        
        if found_item:
            item_id = found_item.get("id")
            console.print(f"[bold green]ID trouvé pour '{item_name}':[/bold green] {item_id}")
            
            console.print("[bold blue]--- DÉBUT RÉCUPÉRATION DÉTAILS ---[/bold blue]")
            details = api_client.get_item_details(glpi_itemtype, item_id)
            console.print("[bold blue]Réponse complète des détails (JSON brut):[/bold blue]")
            print_json(data=details)
        else:
            console.print(Panel(
                f"[bold yellow]Avertissement:[/bold yellow] Aucun objet nommé '{item_name}' de type '{glpi_itemtype}' trouvé.",
                title="[yellow]Résultat de la Recherche[/yellow]"
            ))

    except Exception as e:
        console.print(Panel(
            f"[bold red]Une erreur est survenue:[/bold red] {e}",
            title="[red]Erreur[/red]"
        ))
    finally:
        if is_connected:
            api_client.close_session()
            console.print("[bold green]Session API fermée.[/bold green]")

if __name__ == "__main__":
    main()