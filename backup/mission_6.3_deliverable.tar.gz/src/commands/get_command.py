from src.commands.base_command import BaseCommand
from rich.table import Table
from rich.panel import Panel
from rich.console import Group
from rich.text import Text
from rich import box
from src.api_client import ApiClient

class GetCommand(BaseCommand):
    def execute(self, args):
        if not args:
            self.console.print(Panel("[bold red]Erreur:[/bold red] La commande 'get' nécessite deux arguments.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
            return
        
        try:
            user_type_alias, item_name = args.split(maxsplit=1)
        except ValueError:
            self.console.print(Panel("[bold red]Erreur:[/bold red] Syntaxe incorrecte. Il manque soit le type, soit le nom de l'objet.\nUsage: get <type> <nom_objet>", title="[red]Utilisation[/red]"))
            return

        glpi_itemtype = self.TYPE_ALIASES.get(user_type_alias.lower())
        
        if not glpi_itemtype:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Le type '{user_type_alias}' est inconnu.", title="[red]Type Inconnu[/red]"))
            return
        
        with self.console.status(f"Récupération de la liste des '{glpi_itemtype}'..."):
            # On demande tous les items du type donné
            all_items = self.api_client.list_items(glpi_itemtype, item_range="0-9999")

        if not all_items:
            self.console.print(Panel(f"Aucun objet de type '{user_type_alias}' trouvé dans GLPI.", title="[blue]Information[/blue]", border_style="blue"))
            return

        # Recherche de l'item par son nom dans la liste reçue
        found_item = None
        for item in all_items:
            # On peut rendre la comparaison insensible à la casse pour plus de flexibilité
            if item.get("name", "").lower() == item_name.lower():
                found_item = item
                break
        
        if found_item is None:
            self.console.print(Panel(f"Erreur: Aucun objet de type '{user_type_alias}' nommé '{item_name}' trouvé.", title="[red]Non trouvé[/red]"))
            return

        # On a trouvé l'item, on a son ID
        item_id = found_item.get("id")

        with self.console.status(f"Récupération des détails de {item_name}..."):
            details = self.api_client.get_item_details(glpi_itemtype, item_id)
        
        if details:
            network_ports_data = details.get("_networkports", {})
            total_ports = 0
            if network_ports_data:
                for port_list in network_ports_data.values():
                    total_ports += len(port_list)
            
            MAX_PORTS_FOR_SINGLE_TABLE = 5

            if total_ports <= MAX_PORTS_FOR_SINGLE_TABLE:
                # --- CAS 1 : PEU DE PORTS -> Affichage en une seule table (code de la Mission 6.2) ---
                table = Table(title=f"Détails de {item_name}", expand=True)
                
                # Colonnes de base
                table.add_column("ID")
                table.add_column("Nom")
                table.add_column("Type")
                table.add_column("Statut")
                table.add_column("Localisation")
                table.add_column("Fabricant")

                # Données de base
                base_data = [
                    str(details.get("id")),
                    details.get("name"),
                    glpi_itemtype,
                    str(details.get("states_id", "N/A")),
                    str(details.get("locations_id", "N/A")),
                    str(details.get("manufacturers_id", "N/A")),
                ]

                # Données des ports
                port_data = []
                if network_ports_data:
                    for port_type, port_list in network_ports_data.items():
                        for port in port_list:
                            # Ajoute une colonne pour ce port
                            table.add_column(port.get("name", "Port sans nom"))
                            # Ajoute la donnée correspondante
                            port_info = f"{port.get('speed', 'N/A')} Mbps" # Info simple pour l'instant
                            port_data.append(port_info)

                # Ajoute la ligne complète à la table
                table.add_row(*(base_data + port_data))

                self.console.print(Panel(table))
            else:
                # --- CAS 2 : BEAUCOUP DE PORTS -> Affichage en deux tables (code de la Mission 3.1/5.3) ---
                
                # Table 1 : Infos Générales
                info_table = Table(title="Informations Générales", expand=True)
                info_table.add_column("ID")
                info_table.add_column("Nom")
                info_table.add_column("Type")
                info_table.add_column("Statut")
                info_table.add_column("Localisation")
                info_table.add_column("Fabricant")
                
                info_table.add_row(
                    str(details.get("id")),
                    details.get("name"),
                    glpi_itemtype,
                    str(details.get("states_id", "N/A")),
                    str(details.get("locations_id", "N/A")),
                    str(details.get("manufacturers_id", "N/A")),
                )
                
                # Table 2 : Ports Réseau
                ports_table = Table(title="Ports Réseau", expand=True)
                ports_table.add_column("Nom du Port")
                ports_table.add_column("Type")
                ports_table.add_column("MAC")
                ports_table.add_column("Vitesse")
                
                for port_type, port_list in network_ports_data.items():
                    for port in port_list:
                        ports_table.add_row(
                            port.get("name", "N/A"),
                            port_type,
                            port.get("mac", "N/A"),
                            f"{port.get('speed', 'N/A')} Mbps"
                        )
                
                # Affichage groupé dans un Panel
                render_group = Group(info_table, Text(""), ports_table)
                self.console.print(Panel(render_group, title=f"[bold blue]Détails de {item_name}[/bold blue]"))
        else:
            self.console.print(Panel(f"[bold red]Erreur:[/bold red] Impossible de récupérer les détails pour '{item_name}'.", title="[red]Erreur[/red]"))

